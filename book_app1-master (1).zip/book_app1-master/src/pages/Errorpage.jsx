import React from 'react'

export default function Errorpage() {
  return (
    <div>
      Eroor....
    </div>
  )
}
